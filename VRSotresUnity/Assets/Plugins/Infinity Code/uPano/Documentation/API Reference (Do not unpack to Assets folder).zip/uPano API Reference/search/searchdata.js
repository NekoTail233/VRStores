var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuvwy",
  1: "abcdfghijklmoprstuw",
  2: "i",
  3: "acdefghijlnoprstuvw",
  4: "abcdefiklmnoprstuvwy",
  5: "acelmnprtv",
  6: "acdefilmnoprs",
  7: "abcdefghiklmnpqrstuvwy",
  8: "u"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Pages"
};

