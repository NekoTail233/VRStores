var class_infinity_code_1_1u_pano_1_1_global_settings =
[
    [ "afterTransitionPrefab", "class_infinity_code_1_1u_pano_1_1_global_settings.html#a5995a93d61d6caa89a03ee3d79cbddc1", null ],
    [ "beforeTransitionPrefab", "class_infinity_code_1_1u_pano_1_1_global_settings.html#a2f303fb2f287d669b1ba44acb8b1930b", null ],
    [ "defaultDirectionPrefab", "class_infinity_code_1_1u_pano_1_1_global_settings.html#a496157a121d97cfb4067f5e60265a258", null ],
    [ "defaultHotSpotPrefab", "class_infinity_code_1_1u_pano_1_1_global_settings.html#a153788c00c1cc0e06fdfa4f55c78a6c7", null ],
    [ "instance", "class_infinity_code_1_1u_pano_1_1_global_settings.html#a49c569fa8b3b7b4fdc08324593dc8ae2", null ]
];