var class_infinity_code_1_1u_pano_1_1_cube_u_v_presets =
[
    [ "horizontalCrossPreset", "class_infinity_code_1_1u_pano_1_1_cube_u_v_presets.html#acb0897ba61d6c087fa93d33d63959555", null ],
    [ "verticalCrossPreset", "class_infinity_code_1_1u_pano_1_1_cube_u_v_presets.html#a4a096d04e9aac384a7aed6f15035c8e4", null ],
    [ "youtubePreset", "class_infinity_code_1_1u_pano_1_1_cube_u_v_presets.html#a2fbafdf0aece6b4ab511a8ec6d764bac", null ]
];