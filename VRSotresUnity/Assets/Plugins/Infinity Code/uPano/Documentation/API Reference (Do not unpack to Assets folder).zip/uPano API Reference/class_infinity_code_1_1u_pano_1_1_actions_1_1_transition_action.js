var class_infinity_code_1_1u_pano_1_1_actions_1_1_transition_action =
[
    [ "Invoke", "class_infinity_code_1_1u_pano_1_1_actions_1_1_transition_action.html#aa72ea5a3865a44c6ffdc88fac55ce1fe", null ],
    [ "afterTransitionPrefab", "class_infinity_code_1_1u_pano_1_1_actions_1_1_transition_action.html#a71553caf77db2f9f8170bc91b58f4a81", null ],
    [ "beforeTransitionPrefab", "class_infinity_code_1_1u_pano_1_1_actions_1_1_transition_action.html#a1dbb66047e5311a57881339d16f5c855", null ],
    [ "useTransition", "class_infinity_code_1_1u_pano_1_1_actions_1_1_transition_action.html#a4b4c869225919f20401ffe59676ec0f2", null ]
];