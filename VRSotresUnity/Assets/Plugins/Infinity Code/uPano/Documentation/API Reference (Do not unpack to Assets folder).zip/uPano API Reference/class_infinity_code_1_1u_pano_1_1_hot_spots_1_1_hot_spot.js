var class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot =
[
    [ "TooltipAction", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#a82b5bf1a20a4ae880fbbd483c7d709b9", null ],
    [ "Destroy", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#afe8dd255c5c111ea74dec2d34ea6e3fd", null ],
    [ "GetPanTilt", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#a88ff45b5ab0d282f05512c2ecbb20c95", null ],
    [ "GetScreenPosition", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#add4bcb172494e60e6c39ba8c840883cc", null ],
    [ "InitQuickActions", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#aa4578c6ad8c3850b6de48eab58d1e50d", null ],
    [ "Reinit", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#a059ea77bd600904add5b877341b9117a", null ],
    [ "SetPanTilt", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#ada7913e691df407e2ec9802031499763", null ],
    [ "UpdatePosition", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#aff2da0a4f0159bb2baee2616b5a57a2b", null ],
    [ "tooltip", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#ab9783b67b99a95a44f4c29271c587518", null ],
    [ "tooltipAction", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#aeb9429bf7859644519a276b095b5dae6", null ],
    [ "tooltipPrefab", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#a5c9960428ede4f562c9cbc15d6bb4225", null ],
    [ "distanceMultiplier", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#a5bc2e69c8d5fbc23456e1957a5c6ff20", null ],
    [ "instance", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#aff032cec6e577c2710184f51abb1092b", null ],
    [ "manager", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#ad23862eae2bda1057a80c7648f88d868", null ],
    [ "pan", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#a6aeae65c2242ea06a5c29b8f3f5551f1", null ],
    [ "prefab", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#a96f41ea2624ec6d89dceb8b709dca776", null ],
    [ "rotation", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#ad6933ce07072c08f8a0a3671d31f8321", null ],
    [ "scale", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#a8a882839a0a740a2777844efe51905cf", null ],
    [ "screenPosition", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#a4894289b8b2635abdb316ed480716198", null ],
    [ "tilt", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#a8965569655755ca686d9d8ee6da0ee34", null ],
    [ "worldPosition", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot.html#a30d8787ead146f350a5ae8cdfcc99b0d", null ]
];