var searchData=
[
  ['createnew_1035',['createNew',['../class_infinity_code_1_1u_pano_1_1_pano.html#ac498b3c2b421ed56949527ec09094aaaae637d54b8acec09184b36cbc306ad701',1,'InfinityCode::uPano::Pano']]]
];
