var class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area_global_actions =
[
    [ "instance", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area_global_actions.html#a33bc85c652c7507403c4ada1f1278bb6", null ]
];