var class_infinity_code_1_1u_pano_1_1_actions_1_1_hot_spots_1_1_set_hot_spot_color =
[
    [ "color", "class_infinity_code_1_1u_pano_1_1_actions_1_1_hot_spots_1_1_set_hot_spot_color.html#a3695ffe62363d0061e90d11aebfcf482", null ]
];