var class_infinity_code_1_1u_pano_1_1_actions_1_1_copy_pan_tilt =
[
    [ "source", "class_infinity_code_1_1u_pano_1_1_actions_1_1_copy_pan_tilt.html#ac58378fb5412e2a65047468032204c84", null ],
    [ "target", "class_infinity_code_1_1u_pano_1_1_actions_1_1_copy_pan_tilt.html#aa8c456bb3dff2c1f1fb9b495a17418d5", null ]
];