var class_infinity_code_1_1u_pano_1_1_actions_1_1_set_transform_rotation =
[
    [ "fromIsOriginal", "class_infinity_code_1_1u_pano_1_1_actions_1_1_set_transform_rotation.html#a2d6ee96d1334da81e1f609db2edb201b", null ],
    [ "fromRotation", "class_infinity_code_1_1u_pano_1_1_actions_1_1_set_transform_rotation.html#ac7c8caefdc05b34c5907027281fa0bfb", null ],
    [ "target", "class_infinity_code_1_1u_pano_1_1_actions_1_1_set_transform_rotation.html#ad3852437b54a6c650b92cd61285b6ce1", null ],
    [ "toIsDelta", "class_infinity_code_1_1u_pano_1_1_actions_1_1_set_transform_rotation.html#af4b9d59dd332136e5a47eb656a546210", null ],
    [ "toRotation", "class_infinity_code_1_1u_pano_1_1_actions_1_1_set_transform_rotation.html#a6676fc33e56b0e3b99c914c4943941fc", null ],
    [ "useLocalSpace", "class_infinity_code_1_1u_pano_1_1_actions_1_1_set_transform_rotation.html#af510b046710e0fa3f8a61d889ae6ca07", null ]
];