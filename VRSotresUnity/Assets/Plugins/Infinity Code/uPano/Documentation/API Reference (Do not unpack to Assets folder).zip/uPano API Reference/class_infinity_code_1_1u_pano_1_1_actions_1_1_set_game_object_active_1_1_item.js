var class_infinity_code_1_1u_pano_1_1_actions_1_1_set_game_object_active_1_1_item =
[
    [ "target", "class_infinity_code_1_1u_pano_1_1_actions_1_1_set_game_object_active_1_1_item.html#aaf7dd139b918bbc0144a9ac083c4a96c", null ],
    [ "value", "class_infinity_code_1_1u_pano_1_1_actions_1_1_set_game_object_active_1_1_item.html#adff27b9a60618653a8d3339f5c081de6", null ]
];