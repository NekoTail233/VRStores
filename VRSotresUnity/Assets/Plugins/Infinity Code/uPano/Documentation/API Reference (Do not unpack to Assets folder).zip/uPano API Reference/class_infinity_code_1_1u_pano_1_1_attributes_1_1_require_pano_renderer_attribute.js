var class_infinity_code_1_1u_pano_1_1_attributes_1_1_require_pano_renderer_attribute =
[
    [ "RequirePanoRendererAttribute", "class_infinity_code_1_1u_pano_1_1_attributes_1_1_require_pano_renderer_attribute.html#a74add704e4a505873d0e4e68049a95df", null ],
    [ "type", "class_infinity_code_1_1u_pano_1_1_attributes_1_1_require_pano_renderer_attribute.html#a53a10f77072530a7b6eb19664d21d5e5", null ]
];